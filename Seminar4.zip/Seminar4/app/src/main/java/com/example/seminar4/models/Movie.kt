package com.example.seminar4.models

data class Movie(
    val name: String,
    val description: String,
    val actors: List<String>,
    val budget: Int
)
