package com.example.seminar4

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.Divider
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color.Companion.Black
import androidx.compose.ui.graphics.Color.Companion.DarkGray
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontFamily.Companion.SansSerif
import androidx.compose.ui.text.font.FontFamily.Companion.Serif
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.seminar4.models.Movie
import com.example.seminar4.ui.theme.LightGray
import com.example.seminar4.ui.theme.Seminar4Theme

class DetailedViewActivity : ComponentActivity() {
    val movie = Movie(
        "Thor: Love and Thunder",
        "Fourth movie about Thor in Marvel MCU",
        listOf("Chris Hemsworth", "Christian Bale", "Natalie Portman"),
        250000000
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Seminar4Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    DetailedView(movie)
                }
            }
        }
    }
}

@Composable
fun Name(name: String) {
    Text(
        text = name,
        color = Black,
        fontSize = 30.sp,
        fontFamily = Serif
    )
}

@Composable
fun Description(description: String) {
    Text(
        text = description,
        color = Black,
        fontSize = 18.sp,
        fontFamily = SansSerif
    )
}

@Composable
fun Actors(actors: List<String>) {
    for ((i, value) in  actors.withIndex()){
        ActorTextView(actor = value, isTheLastOne = i == actors.size - 1)
    }
}
@Composable
private fun ActorTextView(actor: String, isTheLastOne: Boolean) {
    Text(
        modifier = Modifier.padding(6.dp, 3.dp),
        text = if (isTheLastOne) actor else "$actor,",
        color = DarkGray,
        fontSize = 19.sp,
        fontFamily = FontFamily.SansSerif,
        fontStyle = FontStyle.Italic
    )
}

@Composable
fun Budget(budget: Int) {
}


@Composable
private fun MyDivider() {
    Divider(
        color = LightGray
    )
}

@Composable
fun DetailedView(movie: Movie) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Bottom
        ) {
            Name(name = movie.name)
            Spacer(Modifier.weight(1f))
            Budget(budget = movie.budget)
        }
        MyDivider()
        Spacer(Modifier.height(16.dp))
        Row(modifier = Modifier
            .fillMaxWidth()
            .padding(5.dp)){
            Description(description = movie.description)

        }
        Actors(actors = movie.actors)

    }

}

@Preview(showBackground = true)
@Composable
fun DefaultPreview2() {
    Seminar4Theme {
        DetailedView(
            Movie(
                "Thor: Love and Thunder",
                "Fourth movie about Thor in Marvel MCU",
                listOf("Chris Hemsworth", "Christian Bale", "Natalie Portman"),
                250000000
            )
        )
    }
}